# IO.Swagger.Model.ODataAllowedActions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OdataContext** | **string** |  | [optional] 
**Value** | [**List&lt;AllowedAction&gt;**](AllowedAction.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

