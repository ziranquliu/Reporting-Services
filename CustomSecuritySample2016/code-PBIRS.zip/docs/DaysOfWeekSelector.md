# IO.Swagger.Model.DaysOfWeekSelector
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sunday** | **bool?** |  | [optional] 
**Monday** | **bool?** |  | [optional] 
**Tuesday** | **bool?** |  | [optional] 
**Wednesday** | **bool?** |  | [optional] 
**Thursday** | **bool?** |  | [optional] 
**Friday** | **bool?** |  | [optional] 
**Saturday** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

