# IO.Swagger.Model.ExpirationReference
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Minutes** | **int?** | Number of minutes until expiration. | [optional] 
**Schedule** | [**ScheduleReference**](ScheduleReference.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

