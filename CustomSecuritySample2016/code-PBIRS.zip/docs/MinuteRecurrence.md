# IO.Swagger.Model.MinuteRecurrence
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinutesInterval** | **int?** | An Int32 value representing interval in minutes. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

