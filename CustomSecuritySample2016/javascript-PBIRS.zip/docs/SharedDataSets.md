# PowerBiReportServerRestApi.SharedDataSets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataSets** | [**[SharedDataSetPath]**](SharedDataSetPath.md) |  | [optional] 


