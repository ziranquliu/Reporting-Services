# PowerBiReportServerRestApi.ODataComments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[Comment]**](Comment.md) |  | [optional] 


