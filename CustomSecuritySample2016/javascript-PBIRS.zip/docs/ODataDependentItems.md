# PowerBiReportServerRestApi.ODataDependentItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[CatalogItem]**](CatalogItem.md) |  | [optional] 


