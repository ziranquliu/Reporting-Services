# PowerBiReportServerRestApi.PowerBIReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hasDataSources** | **Boolean** | A boolean value that indicates whether the PowerBIReport has DataSources. | [optional] 


