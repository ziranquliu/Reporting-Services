# PowerBiReportServerRestApi.ReportParameterState

## Enum


* `hasValidValue` (value: `"HasValidValue"`)

* `missingValidValue` (value: `"MissingValidValue"`)

* `hasOutstandingDependencies` (value: `"HasOutstandingDependencies"`)

* `dynamicValuesUnavailable` (value: `"DynamicValuesUnavailable"`)


