# PowerBiReportServerRestApi.ExcelWorkbook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comments** | [**[Comment]**](Comment.md) | An array of objects of type Comment that are associated with the ExcelWorkbook CatalogItem. | [optional] 


