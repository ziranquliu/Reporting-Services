# PowerBiReportServerRestApi.ItemExecutionType

## Enum


* `live` (value: `"Live"`)

* `cache` (value: `"Cache"`)

* `snapshot` (value: `"Snapshot"`)


