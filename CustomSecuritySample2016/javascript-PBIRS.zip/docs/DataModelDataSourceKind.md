# PowerBiReportServerRestApi.DataModelDataSourceKind

## Enum


* `unknownFunction` (value: `"UnknownFunction"`)

* `analysisServices` (value: `"AnalysisServices"`)

* `SQL` (value: `"SQL"`)

* `file` (value: `"File"`)

* `azureBlobs` (value: `"AzureBlobs"`)

* `oracle` (value: `"Oracle"`)

* `folder` (value: `"Folder"`)

* `mySql` (value: `"MySql"`)

* `teradata` (value: `"Teradata"`)

* `web` (value: `"Web"`)

* `oData` (value: `"OData"`)

* `hDInsight` (value: `"HDInsight"`)

* `azureTables` (value: `"AzureTables"`)

* `sharePoint` (value: `"SharePoint"`)

* `dataMarket` (value: `"DataMarket"`)

* `postgreSQL` (value: `"PostgreSQL"`)

* `sybase` (value: `"Sybase"`)

* `dB2` (value: `"DB2"`)

* `informix` (value: `"Informix"`)

* `MQ` (value: `"MQ"`)

* `activeDirectory` (value: `"ActiveDirectory"`)

* `currentWorkbook` (value: `"CurrentWorkbook"`)

* `exchange` (value: `"Exchange"`)

* `facebook` (value: `"Facebook"`)

* `hdfs` (value: `"Hdfs"`)

* `sapBusinessObjects` (value: `"SapBusinessObjects"`)

* `salesforce` (value: `"Salesforce"`)

* `odbc` (value: `"Odbc"`)

* `googleAnalytics` (value: `"GoogleAnalytics"`)

* `sapBusinessWarehouse` (value: `"SapBusinessWarehouse"`)


