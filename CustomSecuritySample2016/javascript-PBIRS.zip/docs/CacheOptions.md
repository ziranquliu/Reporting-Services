# PowerBiReportServerRestApi.CacheOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executionType** | [**ItemExecutionType**](ItemExecutionType.md) |  | [optional] 
**expiration** | [**ExpirationReference**](ExpirationReference.md) |  | [optional] 


