# PowerBiReportServerRestApi.ODataDataModelRoleAssignments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[DataModelRoleAssignment]**](DataModelRoleAssignment.md) |  | [optional] 


