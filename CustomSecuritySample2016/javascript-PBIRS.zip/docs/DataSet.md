# PowerBiReportServerRestApi.DataSet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hasParameters** | **Boolean** | A boolean value that indicates whether the dataset definition contains parameters. | [optional] 
**queryExecutionTimeOut** | **Number** | An Int32 value that indicates the query execution timeout in seconds. | [optional] 


