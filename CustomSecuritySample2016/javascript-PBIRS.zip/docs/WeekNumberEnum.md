# PowerBiReportServerRestApi.WeekNumberEnum

## Enum


* `firstWeek` (value: `"FirstWeek"`)

* `secondWeek` (value: `"SecondWeek"`)

* `thirdWeek` (value: `"ThirdWeek"`)

* `fourthWeek` (value: `"FourthWeek"`)

* `lastWeek` (value: `"LastWeek"`)


