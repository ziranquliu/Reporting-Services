# PowerBiReportServerRestApi.KpiDataItemType

## Enum


* `_static` (value: `"Static"`)

* `shared` (value: `"Shared"`)


