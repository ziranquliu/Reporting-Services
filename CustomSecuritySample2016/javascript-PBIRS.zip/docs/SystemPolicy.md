# PowerBiReportServerRestApi.SystemPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | A unique UUID value that specifies the identifier of the SystemPolicy. | [optional] 
**policies** | [**[Policy]**](Policy.md) | An array of objects of type Policy that specify the access policies to be applied to the System. | [optional] 


