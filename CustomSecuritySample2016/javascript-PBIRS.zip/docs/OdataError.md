# PowerBiReportServerRestApi.OdataError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**OdataErrorMain**](OdataErrorMain.md) |  | 


