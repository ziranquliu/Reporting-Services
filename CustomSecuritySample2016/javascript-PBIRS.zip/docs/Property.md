# PowerBiReportServerRestApi.Property

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | A string value that specifies the name of the property. | [optional] 
**value** | **String** | A string value that specifies the value for the property. | [optional] 


