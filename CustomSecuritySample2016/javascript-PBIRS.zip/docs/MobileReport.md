# PowerBiReportServerRestApi.MobileReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowCaching** | **Boolean** | A boolean value that indicates whether the MobileReport allows caching. | [optional] 
**manifest** | [**MobileReportManifest**](MobileReportManifest.md) |  | [optional] 
**hasSharedDataSets** | **Boolean** | A boolean value that indicates whether the MobileReport has shared DataSets associated with it. | [optional] 


