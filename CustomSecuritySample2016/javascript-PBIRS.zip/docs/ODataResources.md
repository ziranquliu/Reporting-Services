# PowerBiReportServerRestApi.ODataResources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[Resource]**](Resource.md) |  | [optional] 


