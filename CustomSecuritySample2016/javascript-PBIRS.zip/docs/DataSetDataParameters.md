# PowerBiReportServerRestApi.DataSetDataParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parameters** | [**[DataSetParameter]**](DataSetParameter.md) |  | [optional] 


