# PowerBiReportServerRestApi.DataSetData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**rows** | **[[String]]** |  | [optional] 
**columns** | [**[DataSetColumns]**](DataSetColumns.md) |  | [optional] 


