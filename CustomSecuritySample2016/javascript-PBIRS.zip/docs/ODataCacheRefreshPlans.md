# PowerBiReportServerRestApi.ODataCacheRefreshPlans

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[CacheRefreshPlan]**](CacheRefreshPlan.md) |  | [optional] 


