# PowerBiReportServerRestApi.DailyRecurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**daysInterval** | **Number** | An Int32 value representing interval in days. | [optional] 


