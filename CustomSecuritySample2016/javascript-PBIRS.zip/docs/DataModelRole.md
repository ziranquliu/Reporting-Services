# PowerBiReportServerRestApi.DataModelRole

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modelRoleId** | **String** | A unique UUID value that specifies the identifier of the data model role. | [optional] 
**modelRoleName** | **String** | A string value that specifies the name for the data model role. This name will typically be displayed in the user interface. | [optional] 


