# PowerBiReportServerRestApi.ODataDataSets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[DataSet]**](DataSet.md) |  | [optional] 


