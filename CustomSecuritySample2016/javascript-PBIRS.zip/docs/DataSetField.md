# PowerBiReportServerRestApi.DataSetField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**dataType** | [**ReportParameterType**](ReportParameterType.md) |  | [optional] 


