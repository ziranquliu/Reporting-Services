# PowerBiReportServerRestApi.MoveItemsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**catalogItemPaths** | **[String]** |  | [optional] 
**targetPath** | **String** |  | [optional] 


