# PowerBiReportServerRestApi.ODataFolders

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[Folder]**](Folder.md) |  | [optional] 


