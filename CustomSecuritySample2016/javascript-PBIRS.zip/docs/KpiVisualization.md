# PowerBiReportServerRestApi.KpiVisualization

## Enum


* `none` (value: `"None"`)

* `bar` (value: `"Bar"`)

* `line` (value: `"Line"`)

* `step` (value: `"Step"`)

* `area` (value: `"Area"`)


