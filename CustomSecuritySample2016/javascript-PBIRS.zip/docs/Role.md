# PowerBiReportServerRestApi.Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | A string value that specifies the name of the Role. | [optional] 
**description** | **String** | A string value that constains descriptive text for the Role. | [optional] 


