# PowerBiReportServerRestApi.ValidValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **String** | A string value that specifies the label for the ValidValue. | [optional] 
**value** | **String** | A string value that specifies the value of the ValidValue. | [optional] 


