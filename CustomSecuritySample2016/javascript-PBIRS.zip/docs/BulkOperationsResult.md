# PowerBiReportServerRestApi.BulkOperationsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**failedOperations** | **[String]** |  | [optional] 
**hasErrors** | **Boolean** |  | [optional] 


