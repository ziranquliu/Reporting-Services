# PowerBiReportServerRestApi.MonthlyRecurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days** | **String** | Specifies days for recurrence. | [optional] 
**monthsOfYear** | [**MonthsOfYearSelector**](MonthsOfYearSelector.md) |  | [optional] 


