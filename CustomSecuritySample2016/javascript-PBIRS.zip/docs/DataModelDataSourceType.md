# PowerBiReportServerRestApi.DataModelDataSourceType

## Enum


* `unknown` (value: `"Unknown"`)

* `live` (value: `"Live"`)

* `directQuery` (value: `"DirectQuery"`)

* `_import` (value: `"Import"`)


