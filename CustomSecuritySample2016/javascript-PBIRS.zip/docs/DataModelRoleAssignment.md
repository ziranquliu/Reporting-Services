# PowerBiReportServerRestApi.DataModelRoleAssignment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupUserName** | **String** | A string value that specifies the name of the user or group to which the role assignment applies. | [optional] 
**dataModelRoles** | **[String]** | An array of unique UUID values that specify the identifiers of assigned data model roles. | [optional] 


