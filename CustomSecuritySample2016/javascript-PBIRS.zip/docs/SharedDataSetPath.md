# PowerBiReportServerRestApi.SharedDataSetPath

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | A string value that specifies the name of the shared dataset. | [optional] 
**path** | **String** | A string value that specifies the path to the shared dataset. | [optional] 


