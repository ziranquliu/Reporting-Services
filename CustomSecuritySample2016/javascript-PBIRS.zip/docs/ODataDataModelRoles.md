# PowerBiReportServerRestApi.ODataDataModelRoles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[DataModelRole]**](DataModelRole.md) |  | [optional] 


