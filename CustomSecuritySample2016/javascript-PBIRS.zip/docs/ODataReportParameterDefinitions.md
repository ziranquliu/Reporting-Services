# PowerBiReportServerRestApi.ODataReportParameterDefinitions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[ReportParameterDefinition]**](ReportParameterDefinition.md) |  | [optional] 


