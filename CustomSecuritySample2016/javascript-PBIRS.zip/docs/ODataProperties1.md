# PowerBiReportServerRestApi.ODataProperties1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[Role]**](Role.md) |  | [optional] 


