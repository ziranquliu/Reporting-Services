# PowerBiReportServerRestApi.DataModelDataSourceAuthType

## Enum


* `unknown` (value: `"Unknown"`)

* `anonymous` (value: `"Anonymous"`)

* `integrated` (value: `"Integrated"`)

* `windows` (value: `"Windows"`)

* `usernamePassword` (value: `"UsernamePassword"`)

* `key` (value: `"Key"`)

* `impersonate` (value: `"Impersonate"`)


