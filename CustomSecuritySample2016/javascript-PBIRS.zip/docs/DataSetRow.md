# PowerBiReportServerRestApi.DataSetRow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | A unique UUID value that specifies the identifier by which this item can be referenced. | [optional] 


