# PowerBiReportServerRestApi.KpiValues

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **String** | A string value that specifies the value of the Value Property for the KPI. | [optional] 
**goal** | **Number** | A Double value that specifies the value of the Goal Property for the KPI. | [optional] 
**status** | **Number** | A Double value that specifies the value of the Status Property for the KPI. | [optional] 
**trendSet** | **[Number]** | An array of values that specifies the trendset for the KPI. | [optional] 


