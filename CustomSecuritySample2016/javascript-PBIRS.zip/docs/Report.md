# PowerBiReportServerRestApi.Report

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hasDataSources** | **Boolean** | A boolean value that indicates whether the Report has DataSources associated with it. | [optional] 
**hasSharedDataSets** | **Boolean** | A boolean value that indicates whether the Report has shared DataSets associated with it. | [optional] 
**hasParameters** | **Boolean** | A boolean value that indicates whether the Report has parameters. | [optional] 


