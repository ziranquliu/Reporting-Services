# PowerBiReportServerRestApi.MobileReportThumbnailType

## Enum


* `unknown` (value: `"Unknown"`)

* `landscape` (value: `"Landscape"`)

* `portrait` (value: `"Portrait"`)


