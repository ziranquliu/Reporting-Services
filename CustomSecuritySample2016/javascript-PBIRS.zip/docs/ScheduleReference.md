# PowerBiReportServerRestApi.ScheduleReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scheduleId** | **String** | The Id property of an existing schedule that will be used in the current context. | [optional] 
**definition** | [**ScheduleDefinition**](ScheduleDefinition.md) |  | [optional] 


