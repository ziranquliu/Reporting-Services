# PowerBiReportServerRestApi.MonthlyDOWRecurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**whichWeek** | [**WeekNumberEnum**](WeekNumberEnum.md) |  | [optional] 
**whichWeekSpecified** | **Boolean** | Specifies whether week is specified | [optional] 
**daysOfWeek** | [**DaysOfWeekSelector**](DaysOfWeekSelector.md) |  | [optional] 
**monthsOfYear** | [**MonthsOfYearSelector**](MonthsOfYearSelector.md) |  | [optional] 


