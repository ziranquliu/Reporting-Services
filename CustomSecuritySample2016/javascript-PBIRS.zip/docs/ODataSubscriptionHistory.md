# PowerBiReportServerRestApi.ODataSubscriptionHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[SubscriptionHistory]**](SubscriptionHistory.md) |  | [optional] 


