# PowerBiReportServerRestApi.DrillthroughTargetType

## Enum


* `url` (value: `"Url"`)

* `catalogItem` (value: `"CatalogItem"`)


