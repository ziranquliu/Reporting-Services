# PowerBiReportServerRestApi.KpiValueFormat

## Enum


* `general` (value: `"General"`)

* `abbreviated` (value: `"Abbreviated"`)

* `defaultCurrency` (value: `"DefaultCurrency"`)

* `defaultCurrencyWithDecimals` (value: `"DefaultCurrencyWithDecimals"`)

* `abbreviatedDefaultCurrency` (value: `"AbbreviatedDefaultCurrency"`)

* `percent` (value: `"Percent"`)

* `percentWithDecimals` (value: `"PercentWithDecimals"`)


