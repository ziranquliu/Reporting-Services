# PowerBiReportServerRestApi.ResourceItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | [optional] 


