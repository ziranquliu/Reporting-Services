# PowerBiReportServerRestApi.KpiData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**KpiDataItem**](KpiDataItem.md) |  | [optional] 
**goal** | [**KpiDataItem**](KpiDataItem.md) |  | [optional] 
**status** | [**KpiDataItem**](KpiDataItem.md) |  | [optional] 
**trendSet** | [**KpiDataItem**](KpiDataItem.md) |  | [optional] 


