# PowerBiReportServerRestApi.Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


