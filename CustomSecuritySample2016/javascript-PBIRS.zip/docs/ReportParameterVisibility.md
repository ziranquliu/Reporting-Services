# PowerBiReportServerRestApi.ReportParameterVisibility

## Enum


* `visible` (value: `"Visible"`)

* `hidden` (value: `"Hidden"`)

* `internal` (value: `"Internal"`)


