# PowerBiReportServerRestApi.ScheduleRecurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**minuteRecurrence** | [**MinuteRecurrence**](MinuteRecurrence.md) |  | [optional] 
**dailyRecurrence** | [**DailyRecurrence**](DailyRecurrence.md) |  | [optional] 
**weeklyRecurrence** | [**WeeklyRecurrence**](WeeklyRecurrence.md) |  | [optional] 
**monthlyRecurrence** | [**MonthlyRecurrence**](MonthlyRecurrence.md) |  | [optional] 
**monthlyDOWRecurrence** | [**MonthlyDOWRecurrence**](MonthlyDOWRecurrence.md) |  | [optional] 


