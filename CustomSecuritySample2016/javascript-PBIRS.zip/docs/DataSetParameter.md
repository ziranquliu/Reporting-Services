# PowerBiReportServerRestApi.DataSetParameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The name of the parameter. | [optional] 
**value** | **String** | The value to set for the parameter. | [optional] 


