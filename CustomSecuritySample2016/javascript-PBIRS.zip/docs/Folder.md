# PowerBiReportServerRestApi.Folder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


