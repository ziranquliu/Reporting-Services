# PowerBiReportServerRestApi.ODataDataSetRows

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[DataSetRow]**](DataSetRow.md) |  | [optional] 


