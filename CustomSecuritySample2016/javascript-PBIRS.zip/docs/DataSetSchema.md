# PowerBiReportServerRestApi.DataSetSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The name of the DataSet. | [optional] 
**fields** | [**[DataSetField]**](DataSetField.md) | The fields of the DataSet. | [optional] 
**parameters** | [**[DataSetParameterInfo]**](DataSetParameterInfo.md) | The parameters for the DataSet. | [optional] 


