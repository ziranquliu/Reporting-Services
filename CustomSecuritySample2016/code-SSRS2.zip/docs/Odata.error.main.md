# IO.Swagger.Model.OdataErrorMain
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **string** |  | 
**Message** | **string** |  | 
**Target** | **string** |  | [optional] 
**Details** | [**List&lt;OdataErrorDetail&gt;**](OdataErrorDetail.md) |  | [optional] 
**Innererror** | **Object** | The structure of this object is service-specific. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

