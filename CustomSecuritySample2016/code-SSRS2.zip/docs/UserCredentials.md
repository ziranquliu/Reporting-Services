# IO.Swagger.Model.UserCredentials
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserName** | **string** | A string value that specifies the user name for the user. | [optional] 
**Password** | **string** | A string value that specifies the password for the user. | [optional] 
**Domain** | **string** | A string value that specifies the domain for the user. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

