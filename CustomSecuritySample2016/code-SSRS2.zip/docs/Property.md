# IO.Swagger.Model.Property
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | A string value that specifies the name of the property. | [optional] 
**Value** | **string** | A string value that specifies the value for the property. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

