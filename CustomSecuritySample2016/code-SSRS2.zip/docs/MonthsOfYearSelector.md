# IO.Swagger.Model.MonthsOfYearSelector
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**January** | **bool?** |  | [optional] 
**February** | **bool?** |  | [optional] 
**March** | **bool?** |  | [optional] 
**April** | **bool?** |  | [optional] 
**May** | **bool?** |  | [optional] 
**June** | **bool?** |  | [optional] 
**July** | **bool?** |  | [optional] 
**August** | **bool?** |  | [optional] 
**September** | **bool?** |  | [optional] 
**October** | **bool?** |  | [optional] 
**November** | **bool?** |  | [optional] 
**December** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

