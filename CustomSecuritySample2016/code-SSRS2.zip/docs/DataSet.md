# IO.Swagger.Model.DataSet
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HasParameters** | **bool?** | A boolean value that indicates whether the dataset definition contains parameters. | [optional] 
**QueryExecutionTimeOut** | **int?** | An Int32 value that indicates the query execution timeout in seconds. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

