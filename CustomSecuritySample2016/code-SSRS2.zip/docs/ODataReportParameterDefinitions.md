# IO.Swagger.Model.ODataReportParameterDefinitions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OdataContext** | **string** |  | [optional] 
**Value** | [**List&lt;ReportParameterDefinition&gt;**](ReportParameterDefinition.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

