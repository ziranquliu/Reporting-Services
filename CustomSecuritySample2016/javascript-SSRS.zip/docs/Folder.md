# SqlServer2017ReportingServicesRestApi.Folder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


