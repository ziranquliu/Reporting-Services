# SqlServer2017ReportingServicesRestApi.MinuteRecurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**minutesInterval** | **Number** | An Int32 value representing interval in minutes. | [optional] 


