# SqlServer2017ReportingServicesRestApi.DrillthroughTargetType

## Enum


* `url` (value: `"Url"`)

* `catalogItem` (value: `"CatalogItem"`)


