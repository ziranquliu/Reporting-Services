# SqlServer2017ReportingServicesRestApi.Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


