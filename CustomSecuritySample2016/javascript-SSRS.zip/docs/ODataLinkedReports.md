# SqlServer2017ReportingServicesRestApi.ODataLinkedReports

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[LinkedReport]**](LinkedReport.md) |  | [optional] 


