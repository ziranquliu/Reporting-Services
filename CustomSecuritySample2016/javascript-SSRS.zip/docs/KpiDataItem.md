# SqlServer2017ReportingServicesRestApi.KpiDataItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**KpiDataItemType**](KpiDataItemType.md) |  | [optional] 


