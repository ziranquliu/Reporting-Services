# SqlServer2017ReportingServicesRestApi.DaysOfWeekSelector

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | **Boolean** |  | [optional] 
**monday** | **Boolean** |  | [optional] 
**tuesday** | **Boolean** |  | [optional] 
**wednesday** | **Boolean** |  | [optional] 
**thursday** | **Boolean** |  | [optional] 
**friday** | **Boolean** |  | [optional] 
**saturday** | **Boolean** |  | [optional] 


