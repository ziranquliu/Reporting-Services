# SqlServer2017ReportingServicesRestApi.ThumbnailItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**MobileReportThumbnailType**](MobileReportThumbnailType.md) |  | [optional] 


