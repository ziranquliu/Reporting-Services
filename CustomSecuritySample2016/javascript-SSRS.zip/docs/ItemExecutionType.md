# SqlServer2017ReportingServicesRestApi.ItemExecutionType

## Enum


* `live` (value: `"Live"`)

* `cache` (value: `"Cache"`)

* `snapshot` (value: `"Snapshot"`)


