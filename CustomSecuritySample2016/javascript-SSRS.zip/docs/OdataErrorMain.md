# SqlServer2017ReportingServicesRestApi.OdataErrorMain

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | 
**message** | **String** |  | 
**target** | **String** |  | [optional] 
**details** | [**[OdataErrorDetail]**](OdataErrorDetail.md) |  | [optional] 
**innererror** | **Object** | The structure of this object is service-specific. | [optional] 


