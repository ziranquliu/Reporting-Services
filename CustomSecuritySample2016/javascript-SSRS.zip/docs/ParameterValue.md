# SqlServer2017ReportingServicesRestApi.ParameterValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | A string that contains the name of the parameter. | [optional] 
**value** | **String** | A string that contains the value for the parameter. | [optional] 
**isValueFieldReference** | **Boolean** | A boolean value that indicates if the parameter's value references a field. | [optional] 


