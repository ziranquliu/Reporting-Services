# SqlServer2017ReportingServicesRestApi.AllowedAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **String** | The allowed action. | [optional] 


