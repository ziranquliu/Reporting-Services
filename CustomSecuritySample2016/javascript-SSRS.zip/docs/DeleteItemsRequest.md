# SqlServer2017ReportingServicesRestApi.DeleteItemsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**catalogItemPaths** | **[String]** |  | [optional] 


