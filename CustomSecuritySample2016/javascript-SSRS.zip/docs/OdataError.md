# SqlServer2017ReportingServicesRestApi.OdataError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**OdataErrorMain**](OdataErrorMain.md) |  | 


