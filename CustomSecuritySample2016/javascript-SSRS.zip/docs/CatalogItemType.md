# SqlServer2017ReportingServicesRestApi.CatalogItemType

## Enum


* `unknown` (value: `"Unknown"`)

* `folder` (value: `"Folder"`)

* `report` (value: `"Report"`)

* `dataSource` (value: `"DataSource"`)

* `dataSet` (value: `"DataSet"`)

* `component` (value: `"Component"`)

* `resource` (value: `"Resource"`)

* `kpi` (value: `"Kpi"`)

* `mobileReport` (value: `"MobileReport"`)

* `linkedReport` (value: `"LinkedReport"`)

* `reportModel` (value: `"ReportModel"`)


