# SqlServer2017ReportingServicesRestApi.DataSetField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**dataType** | [**ReportParameterType**](ReportParameterType.md) |  | [optional] 


