# SqlServer2017ReportingServicesRestApi.Query

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commandText** | **String** | Command to be executed against given data source | [optional] 
**timeout** | **Number** | Query Timeout, default is 30 seconds. | [optional] 


