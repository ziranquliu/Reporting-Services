# SqlServer2017ReportingServicesRestApi.ResourceGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**MobileReportResourceGroupType**](MobileReportResourceGroupType.md) |  | [optional] 
**items** | [**[ResourceItem]**](ResourceItem.md) | An array of objects of type ResourceItem that contain the contents of the ResourceGroup. | [optional] 


