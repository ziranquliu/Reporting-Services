# SqlServer2017ReportingServicesRestApi.ReportParameterState

## Enum


* `hasValidValue` (value: `"HasValidValue"`)

* `missingValidValue` (value: `"MissingValidValue"`)

* `hasOutstandingDependencies` (value: `"HasOutstandingDependencies"`)

* `dynamicValuesUnavailable` (value: `"DynamicValuesUnavailable"`)


