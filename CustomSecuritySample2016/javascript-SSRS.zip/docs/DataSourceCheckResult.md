# SqlServer2017ReportingServicesRestApi.DataSourceCheckResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isSuccessful** | **Boolean** |  | [optional] 
**errorMessage** | **String** |  | [optional] 


