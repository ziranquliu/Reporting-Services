# SqlServer2017ReportingServicesRestApi.ODataKpis

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[Kpi]**](Kpi.md) |  | [optional] 


