# SqlServer2017ReportingServicesRestApi.MonthsOfYearSelector

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**january** | **Boolean** |  | [optional] 
**february** | **Boolean** |  | [optional] 
**march** | **Boolean** |  | [optional] 
**april** | **Boolean** |  | [optional] 
**may** | **Boolean** |  | [optional] 
**june** | **Boolean** |  | [optional] 
**july** | **Boolean** |  | [optional] 
**august** | **Boolean** |  | [optional] 
**september** | **Boolean** |  | [optional] 
**october** | **Boolean** |  | [optional] 
**november** | **Boolean** |  | [optional] 
**december** | **Boolean** |  | [optional] 


