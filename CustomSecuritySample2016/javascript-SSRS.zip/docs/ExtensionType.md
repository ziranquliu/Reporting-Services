# SqlServer2017ReportingServicesRestApi.ExtensionType

## Enum


* `delivery` (value: `"Delivery"`)

* `deliveryUI` (value: `"DeliveryUI"`)

* `render` (value: `"Render"`)

* `data` (value: `"Data"`)

* `all` (value: `"All"`)


