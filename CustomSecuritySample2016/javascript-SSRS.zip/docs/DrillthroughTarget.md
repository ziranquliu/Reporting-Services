# SqlServer2017ReportingServicesRestApi.DrillthroughTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**drillthroughTargetType** | [**DrillthroughTargetType**](DrillthroughTargetType.md) |  | [optional] 


