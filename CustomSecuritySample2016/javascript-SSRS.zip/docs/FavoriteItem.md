# SqlServer2017ReportingServicesRestApi.FavoriteItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | A unique UUID value that specifies the identifier of the CatalogItem that is marked as a favorite. | [optional] 
**item** | [**CatalogItem**](CatalogItem.md) |  | [optional] 


