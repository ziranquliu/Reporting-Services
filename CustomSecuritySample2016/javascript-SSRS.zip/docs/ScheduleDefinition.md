# SqlServer2017ReportingServicesRestApi.ScheduleDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startDateTime** | **Date** | A string that specifies the date-time of the start of the schedule. | [optional] 
**endDate** | **Date** | A string that specifies the date-time of the end of the schedule. | [optional] 
**endDateSpecified** | **Boolean** | A boolean value that indicates whether the schedule end is specified. | [optional] 
**recurrence** | [**ScheduleRecurrence**](ScheduleRecurrence.md) |  | [optional] 


