# SqlServer2017ReportingServicesRestApi.ResourceItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | [optional] 


