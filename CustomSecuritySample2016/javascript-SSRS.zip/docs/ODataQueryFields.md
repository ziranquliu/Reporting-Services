# SqlServer2017ReportingServicesRestApi.ODataQueryFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | **[String]** |  | [optional] 


