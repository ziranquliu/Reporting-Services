# SqlServer2017ReportingServicesRestApi.DataSetColumns

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**type** | **String** |  | [optional] 


