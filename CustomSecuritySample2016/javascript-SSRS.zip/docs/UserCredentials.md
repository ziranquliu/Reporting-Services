# SqlServer2017ReportingServicesRestApi.UserCredentials

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userName** | **String** | A string value that specifies the user name for the user. | [optional] 
**password** | **String** | A string value that specifies the password for the user. | [optional] 
**domain** | **String** | A string value that specifies the domain for the user. | [optional] 


