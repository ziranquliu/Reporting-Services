# SqlServer2017ReportingServicesRestApi.KpiDataItemType

## Enum


* `_static` (value: `"Static"`)

* `shared` (value: `"Shared"`)


