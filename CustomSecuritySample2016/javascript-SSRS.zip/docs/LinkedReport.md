# SqlServer2017ReportingServicesRestApi.LinkedReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hasParameters** | **Boolean** | A boolean value that indicates whether the LinkedReport has parameters. | [optional] 
**link** | **String** |  A string value that specifies the path to the report item that this linked report is linked to. | [optional] 


