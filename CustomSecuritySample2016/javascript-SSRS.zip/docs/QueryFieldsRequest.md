# SqlServer2017ReportingServicesRestApi.QueryFieldsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataSource** | [**DataSource**](DataSource.md) |  | [optional] 
**query** | [**Query**](Query.md) |  | [optional] 


