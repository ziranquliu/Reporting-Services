# SqlServer2017ReportingServicesRestApi.ExtensionSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**extension** | **String** | A string value that specifies the name of the Reporting Services extension that the settings in the object apply to. | [optional] 
**parameterValues** | [**ParameterValue**](ParameterValue.md) |  | [optional] 


