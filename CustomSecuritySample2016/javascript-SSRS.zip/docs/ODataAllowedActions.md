# SqlServer2017ReportingServicesRestApi.ODataAllowedActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[AllowedAction]**](AllowedAction.md) |  | [optional] 


