# SqlServer2017ReportingServicesRestApi.UpdateCacheSnapshotResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Boolean** |  | [optional] 


