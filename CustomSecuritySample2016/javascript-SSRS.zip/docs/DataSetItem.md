# SqlServer2017ReportingServicesRestApi.DataSetItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timeUnit** | **String** | The time unit for the DataSetItem. The possible values for this string are the following: 'Year', 'Quarter', 'Month', 'Weekday', 'Hour'. | [optional] 
**dateTimeColumn** | **String** | A string value that specifies the name of the column in the DataSetItem that represents date and time. | [optional] 


