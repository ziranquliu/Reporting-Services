# SqlServer2017ReportingServicesRestApi.HistorySnapshotOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**catalogItemId** | **String** | The Id of the CatalogItem that this HistorySnapshotOptions belongs to. | [optional] 
**historySnapshotsOptions** | [**ReportHistorySnapshotsOptions**](ReportHistorySnapshotsOptions.md) |  | [optional] 


