# SqlServer2017ReportingServicesRestApi.ReportParameterType

## Enum


* `_boolean` (value: `"Boolean"`)

* `dateTime` (value: `"DateTime"`)

* `integer` (value: `"Integer"`)

* `_float` (value: `"Float"`)

* `_string` (value: `"String"`)


