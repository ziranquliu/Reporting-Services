# SqlServer2017ReportingServicesRestApi.Policy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupUserName** | **String** | A string value that specifies the name of the user or group to which the policy applies. | [optional] 
**roles** | [**[Role]**](Role.md) | An array of objects of type Role that specify the security roles that are included in the Policy. | [optional] 


