# SqlServer2017ReportingServicesRestApi.BulkOperationsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**failedOperations** | **[String]** |  | [optional] 
**hasErrors** | **Boolean** |  | [optional] 


