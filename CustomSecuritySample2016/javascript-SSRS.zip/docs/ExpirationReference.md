# SqlServer2017ReportingServicesRestApi.ExpirationReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**minutes** | **Number** | Number of minutes until expiration. | [optional] 
**schedule** | [**ScheduleReference**](ScheduleReference.md) |  | [optional] 


