# SqlServer2017ReportingServicesRestApi.KpiSharedDataItemAggregation

## Enum


* `none` (value: `"None"`)

* `first` (value: `"First"`)

* `last` (value: `"Last"`)

* `min` (value: `"Min"`)

* `max` (value: `"Max"`)

* `average` (value: `"Average"`)

* `sum` (value: `"Sum"`)


