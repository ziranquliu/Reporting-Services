# SqlServer2017ReportingServicesRestApi.DataSetAggregateValueParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parameters** | [**[DataSetParameter]**](DataSetParameter.md) |  | [optional] 


