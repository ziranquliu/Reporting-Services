# SqlServer2017ReportingServicesRestApi.ODataProperties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**value** | [**[Property]**](Property.md) |  | [optional] 


