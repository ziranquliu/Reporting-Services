# SqlServer2017ReportingServicesRestApi.ODataReports

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[Report]**](Report.md) |  | [optional] 


