# SqlServer2017ReportingServicesRestApi.OdataErrorDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | 
**message** | **String** |  | 
**target** | **String** |  | [optional] 


