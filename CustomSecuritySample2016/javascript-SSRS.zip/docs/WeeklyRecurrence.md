# SqlServer2017ReportingServicesRestApi.WeeklyRecurrence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weeksInterval** | **Number** | An Int32 value representing interval in weeks. | [optional] 
**weeksIntervalSpecified** | **Boolean** | True if using WeeksInterval. | [optional] 
**daysOfWeek** | [**DaysOfWeekSelector**](DaysOfWeekSelector.md) |  | [optional] 


