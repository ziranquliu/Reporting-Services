# SqlServer2017ReportingServicesRestApi.MobileReportResourceGroupType

## Enum


* `unknown` (value: `"Unknown"`)

* `style` (value: `"Style"`)

* `map` (value: `"Map"`)


