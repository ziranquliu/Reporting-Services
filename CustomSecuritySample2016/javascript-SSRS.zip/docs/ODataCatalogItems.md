# SqlServer2017ReportingServicesRestApi.ODataCatalogItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**odataContext** | **String** |  | [optional] 
**odataCount** | **Number** |  | [optional] 
**value** | [**[CatalogItem]**](CatalogItem.md) |  | [optional] 


