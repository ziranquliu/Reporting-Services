# SqlServer2017ReportingServicesRestApi.ItemPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inheritParentPolicy** | **Boolean** | A Boolean value that indicates whether the access policy is to be inherited from the item's parent item. | [optional] 
**policies** | [**[Policy]**](Policy.md) | An array of objects of type Policy that specify the access policies to be applied to the item.       | [optional] 


