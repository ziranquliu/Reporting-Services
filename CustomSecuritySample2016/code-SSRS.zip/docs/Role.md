# IO.Swagger.Model.Role
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | A string value that specifies the name of the Role. | [optional] 
**Description** | **string** | A string value that constains descriptive text for the Role. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

