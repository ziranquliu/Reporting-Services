# IO.Swagger.Model.ODataCacheRefreshPlans
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OdataContext** | **string** |  | [optional] 
**Value** | [**List&lt;CacheRefreshPlan&gt;**](CacheRefreshPlan.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

