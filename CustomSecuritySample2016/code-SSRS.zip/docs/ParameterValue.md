# IO.Swagger.Model.ParameterValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | A string that contains the name of the parameter. | [optional] 
**Value** | **string** | A string that contains the value for the parameter. | [optional] 
**IsValueFieldReference** | **bool?** | A boolean value that indicates if the parameter&#39;s value references a field. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

