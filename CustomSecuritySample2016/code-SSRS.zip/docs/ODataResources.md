# IO.Swagger.Model.ODataResources
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OdataContext** | **string** |  | [optional] 
**OdataCount** | **int?** |  | [optional] 
**Value** | [**List&lt;Resource&gt;**](Resource.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

