# IO.Swagger.Model.DailyRecurrence
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DaysInterval** | **int?** | An Int32 value representing interval in days. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

