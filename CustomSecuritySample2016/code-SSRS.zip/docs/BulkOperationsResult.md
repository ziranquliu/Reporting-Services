# IO.Swagger.Model.BulkOperationsResult
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FailedOperations** | **List&lt;string&gt;** |  | [optional] 
**HasErrors** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

