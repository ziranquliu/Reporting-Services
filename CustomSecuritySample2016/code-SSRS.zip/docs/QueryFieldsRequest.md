# IO.Swagger.Model.QueryFieldsRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataSource** | [**DataSource**](DataSource.md) |  | [optional] 
**Query** | [**Query**](Query.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

