# IO.Swagger.Model.PowerBIReport
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HasDataSources** | **bool?** | A boolean value that indicates whether the PowerBIReport has DataSources. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

