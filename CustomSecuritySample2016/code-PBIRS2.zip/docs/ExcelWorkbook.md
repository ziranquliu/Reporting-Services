# IO.Swagger.Model.ExcelWorkbook
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Comments** | [**List&lt;Comment&gt;**](Comment.md) | An array of objects of type Comment that are associated with the ExcelWorkbook CatalogItem. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

