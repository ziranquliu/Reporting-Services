# IO.Swagger.Model.SharedDataSetPath
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | A string value that specifies the name of the shared dataset. | [optional] 
**Path** | **string** | A string value that specifies the path to the shared dataset. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

