# IO.Swagger.Model.CacheOptions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionType** | **ItemExecutionType** |  | [optional] 
**Expiration** | [**ExpirationReference**](ExpirationReference.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

