# IO.Swagger.Model.ScheduleReference
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ScheduleId** | **Guid?** | The Id property of an existing schedule that will be used in the current context. | [optional] 
**Definition** | [**ScheduleDefinition**](ScheduleDefinition.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

