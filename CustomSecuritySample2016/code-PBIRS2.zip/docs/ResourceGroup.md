# IO.Swagger.Model.ResourceGroup
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **MobileReportResourceGroupType** |  | [optional] 
**Items** | [**List&lt;ResourceItem&gt;**](ResourceItem.md) | An array of objects of type ResourceItem that contain the contents of the ResourceGroup. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

