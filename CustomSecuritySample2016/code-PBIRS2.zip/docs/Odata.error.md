# IO.Swagger.Model.OdataError
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error** | [**OdataErrorMain**](OdataErrorMain.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

