# IO.Swagger.Model.ScheduleRecurrence
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinuteRecurrence** | [**MinuteRecurrence**](MinuteRecurrence.md) |  | [optional] 
**DailyRecurrence** | [**DailyRecurrence**](DailyRecurrence.md) |  | [optional] 
**WeeklyRecurrence** | [**WeeklyRecurrence**](WeeklyRecurrence.md) |  | [optional] 
**MonthlyRecurrence** | [**MonthlyRecurrence**](MonthlyRecurrence.md) |  | [optional] 
**MonthlyDOWRecurrence** | [**MonthlyDOWRecurrence**](MonthlyDOWRecurrence.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

